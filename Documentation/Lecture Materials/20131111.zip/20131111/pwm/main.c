// main.c
// Runs on LM3S1968

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to the Arm Cortex M3",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2011
   Example 2.2, Program 2.8, Figure 2.27

 Copyright 2011 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

/* setup pwm0 to output 0,25,50,75,100% DC waves; increment on interrupt */

// m3 core peripherals base
unsigned char *M3CP = (unsigned char *) 0xE000E000;
// system control base
unsigned char *SYSCTL = (unsigned char *) 0x400FE000;
// base addr for port g
unsigned char *PG = (unsigned char *) 0x40026000;
// base addr for pwm peripheral
unsigned char *PWM = (unsigned char *) 0x40028000;
unsigned short PWM0LOAD __attribute__((at(0x40028050)));
unsigned short PWM0CMPA __attribute__((at(0x40028058)));

void PWM0Init()
{
	// NOTE: PWM0 uses PG2
	// 1a. enable clock for port g (r-m-w cycle)
	SYSCTL[0x108] = SYSCTL[0x108] | 0x40;
	
	//1b. enable clock for pwm (bit 20 of RCGC0)
	SYSCTL[0x102] = 0x10;

	// 2. pin config: alt func & den
	PG[0x420] = 0x4; //alt func
	PG[0x51C] = 0x4; //den
	
	// 3. pwm generator: disable, countdown, immediate updates
	PWM[0x40] = 0x0;
	
	// 4. pwm comparator config:
	//    a. count = load: output=1
	//    b. count = comparator: output=0
	PWM[0x60] = 0x8C;
	
	// 5. pwm timer: set load (initial) value
	//    LOAD = (1/f)/(1/SysClk)-1; f = 25 KHz, SysClk = 12 MHz
	//         = 479 = 0x1DF
	PWM0LOAD = 0x1DF;
	
	// 6. set 25% dc
	//    COMP = (1/f)/(1/SysClk)*(1-DC)-1
	//         = 480*(1-0.25)-1 = 359 = 0x167
	PWM0CMPA = 0x167;
	
	// 7. start pwm0 timer and enable pwm output
	PWM[0x40] = 0x1; //timer
	PWM[0x8] = 0x1; //enable pwm
}

int main(void)
{
	 PWM0Init();
	
	while(1);
}
