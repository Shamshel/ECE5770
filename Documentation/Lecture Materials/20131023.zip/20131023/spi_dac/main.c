// main.c
// Runs on LM3S1968

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to the Arm Cortex M3",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2011
   Example 2.2, Program 2.8, Figure 2.27

 Copyright 2011 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

/* SPI DAC at 2 MHz */
// RCGC1 (for enabling clock to ssi0)
unsigned int RCGC1 __attribute__((at(0x400FE104)));
// RCGC2 (for enabling clock to port a)
unsigned int RCGC2 __attribute__((at(0x400FE108)));
// base addr for port a
unsigned char *PA = (unsigned char *) 0x40004000;
// base addr for ssi0
unsigned char *SSI0 = (unsigned char *) 0x40008000;
// ssi0 data register
unsigned int SSI0DR __attribute__((at(0x40008008)));
// ssi0 status register
volatile unsigned int SSI0SR __attribute__((at(0x4000800C)));

void SSI0Init()
{
	// 0a. activate clock for port a and ssi0
	RCGC1 = 0x10; //ssi0
  RCGC2 = 0x1; //port a
	
  // 0b. enable alt. function: PA[4:2]
	PA[0x420] = 0x1C;
	
	// 0c. direction for Fss
	PA[0x400] = 0x20;

  // 0c. digital enable: PA[5:2]
	PA[0x51C] = 0x3C;
	
	// 0d. disable ssi0 during config (overwrite all settings)
	SSI0[0x4] = 0;
	
	// 1. set role
	SSI0[0x4] = 0; //master
	
	// 2. set prescale and clock rate (SysClk = 12 MHz)
	// 2 MHz = 12 MHz/6 => PRE*(1+CR) = 6 => PRE = 2, CR = 2
	SSI0[0x10] = 0x2; //PRE
	SSI0[0x1] = 0x2; //CR

  // 3. frame format/protocol: 16-bit data, FreeScale, SPH=SPO=0
	SSI0[0x0] |= 0xF; // data size: 16-bits
	SSI0[0x0] &= 0xCF; //frame: freescale (bits four and five are zero)
	SSI0[0x0] &= 0x3F; //SPH=SPO=0 (bits six and zer are zero)
	
	// 4. enable ssi0 (use rmw cycle)
	SSI0[0x4] |= 0x2;
}

int main(void)
{
	unsigned short D;

	SSI0Init();

	//TX every combination of codes as quickly as possible
	D = 0;
	
	//alert slave to fact that we're sending data (Fss=0)
	PA[0x3FC] &= 0xDF; //bring pin five low
	
	while(1)
	{
		while(SSI0SR & 0x2) //get TNF bit; so long as TNF = 1, we can add data
		{
			SSI0DR = D<<1; //C[2:0] means immediate update; LSB must be zero for update
			D = (D+1)%8192; //2^13 = 8192 =0b1000000000000: this ensures D always less than or equal to 0b0111111111111
		}
	}
}
