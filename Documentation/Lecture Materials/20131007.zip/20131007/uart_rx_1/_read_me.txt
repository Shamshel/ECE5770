note: to simulate sending data to the uC, you must use the command window (not the uart1 window):

> S0IN=0xFF

or

> S0IN='A'