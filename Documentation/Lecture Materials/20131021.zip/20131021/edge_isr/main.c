// main.c
// Runs on LM3S1968

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to the Arm Cortex M3",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2011
   Example 2.2, Program 2.8, Figure 2.27

 Copyright 2011 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

// m3 core peripherals base
unsigned char *M3CP = (unsigned char *) 0xE000E000;
// RCGC2 (for enabling clock to gpio port d)
unsigned int RCGC2 __attribute__((at(0x400FE108)));
// base addr for port d
unsigned char *PD = (unsigned char *) 0x40007000;
// pin zero of port d
unsigned char CNT = 0;

void PD0Init()
{
	// 1a. activate clock for port d
  RCGC2 = 0x8;
	
  // 1b. disable alt. function: disabled by default

  // 1c. set PD0 as input
	PD[0x400] = 0;

  // 1d. additional settings: use defaults

  // 1e. enable pin
	PD[0x51C] = 1;
	
	// 2. edge triggering
	PD[0x404] = 0;
	
	// 3. rising edge
	PD[0x408] = 0; //don't want both edges
	PD[0x40C] = 1; //rising edge
	
	// 4. enable pin interrupt
	PD[0x410] = 1;
	
	// 5. enable interrupt from port d: vector number 19, interrupt num 3
	//    interrupt num 3 is in first byte of EN0
	M3CP[0x100] = 0x8;
}

/* one interrupt handler per port */
void GPIOPortD_Handler(void)
{
	// acknowledge interrupt
	PD[0x41C] = 1;
	
	CNT++;
}

int main(void)
{
	PD0Init();
	
	while(1);
}
