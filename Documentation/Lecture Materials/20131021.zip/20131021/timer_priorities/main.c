// main.c
// Runs on LM3S1968

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to the Arm Cortex M3",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2011
   Example 2.2, Program 2.8, Figure 2.27

 Copyright 2011 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

// m3 core peripherals base
unsigned char *M3CP = (unsigned char *) 0xE000E000;
// RCGC1 (for enabling timer zero)
unsigned char *RCGC1 = (unsigned char *) 0x400FE104;
// base addr for timer zero
unsigned char *TM0 = (unsigned char *) 0x40030000;
// initial values for TM0A/B
unsigned short TM0A_INIT __attribute__((at(0x40030028)));
unsigned short TM0B_INIT __attribute__((at(0x4003002C)));

// init both timers at the same time
void TM0Init()
{
	// 0. enable clock for GPTM0: timer0 is locate in second byte of RCGC1
	RCGC1[0x2] = 0x1;

	/* interrupt setup */
	// timer0a is interrupt #19 (offset 0x8c), timber0b is #20 (offset 0x90)
	// 1. enable interrupts for timer0a/b: second byte of EN0 register
	M3CP[0x102] = 0x18; //0x18 = 0b00011000
	
	// 2. set priorities: timer0a=2, timer0b=1 (timer0b has greater priority)
	//timer0a priority is set in last byte of PRI4
	M3CP[0x413] = 0x40; //0x40=010000000
  //timer0b priority is set in first byte of PRI5
	M3CP[0x414] = 0x20; //0x20=001000000
	
	/* timer setup */
	// 1. stop timers
	TM0[0xC] = 0;
	TM0[0xD] = 0;
	
  // 2. enable 16-bit mode
  TM0[0x0] = 0x4;
	
	// 3. set periodic
	TM0[0x4] = 0x2;
	TM0[0x8] = 0x2;

  // 4. set initial value
	TM0A_INIT = 0xF;
	TM0B_INIT = 0x15;
	
	// 5. enable interrupts
	TM0[0x18] = 0x1;
	TM0[0x19] = 0x1;

  // 6. start timer (please note that the GPTM0 peripheral dialog box must be open before this point)
  TM0[0xC] = 0x1;
	TM0[0xD] = 0x1;
}

// not as important stuff happening here
void Timer0A_Handler(void)
{
	unsigned int i,j;

	// let timer know interrupt has been handled
	TM0[0x24] = 0x1;
	
	// have to do something in loop, or compiler removes it...
	for(i=0;i<10;i++)
		j++;
}

// important stuff happening here
void Timer0B_Handler(void)
{	
	unsigned int i,j;
	// let timer know interrupt has been handled
	TM0[0x25] = 0x1;
	
	// have to do something in loop, or compiler removes it...
	for(i=0;i<5;i++)
		j++;
}

int main(void)
{
	TM0Init();

	// interrupts take twelve cycles to be acknowledged...
  while(1);
}
