// main.c
// Runs on LM3S1968

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to the Arm Cortex M3",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2011
   Example 2.2, Program 2.8, Figure 2.27

 Copyright 2011 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

// base addr for port d
unsigned char *IOCON_DAC = (unsigned char *) 0x4002C068;
// code for dac to output (bits 6:15)
unsigned short DAC_CR __attribute__((at(0x4008C000)));
// ten entry sine table
unsigned short SIN_10[] = {512,842,1017,956,688,337,69,8,183,512};

void DACInit()
{
	// dac functionality for pin
	IOCON_DAC[0] = 0x2;
	
	// enable dac
	IOCON_DAC[2] = 0x1;
}


int main(void)
{
  unsigned int i;
	unsigned int delay;

	DACInit();

	while(1)
		for(i=0;i<10;i++)
			{	
				DAC_CR = (SIN_10[i]<<6);
				for(delay=0;delay<1024;delay++);
			}
}
