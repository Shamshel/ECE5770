// main.c
// Runs on LM3S1968

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to the Arm Cortex M3",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2011
   Example 2.2, Program 2.8, Figure 2.27

 Copyright 2011 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

// m3 core peripherals base
unsigned char *M3CP = (unsigned char *) 0xE000E000;
// PD0 setup (chars at bb addr: take advantage of the fact that write to bb addr only writes lsb)
unsigned char PD0_DATA_B __attribute__((at(0x420E7F80)));
unsigned char PD0_DIR_B __attribute__((at(0x420E8000)));
unsigned char PD0_EN_B __attribute__((at(0x420EA380)));
unsigned char CLK_PD_B __attribute__((at(0x43FC210C)));
// count the number of times systick isr called
unsigned int CNT = 0;

void SysTickInit()
{
  // 1. stop timer
	M3CP[0x10] = 0;

  // 2. set init value (RELOAD)
  M3CP[0x14] = 0xFF;
	
  // 3. clear current timer value (any write clears CURRENT)
	M3CP[0x18] = 0;
	
  // 4. set options and start counting
  // clk_src=system clock
  // inten=1 (trigger interrupt at timer expiration)
  // enable=1 (start counting)
	M3CP[0x10] = 0x7; //0x7 = 0b111 (CLK_SRC,INTEN,ENABLE)
}

void PD0Init()
{
	// 1. activate clock for port d
  CLK_PD_B = 1;
	
  // 2. disable alt. function: disabled by default

  // 3. set PD0 as output
	PD0_DIR_B = 1;

  // 4. additional settings: use defaults

  // 5. enable port
	PD0_EN_B = 1;
}

void SysTick_Handler(void)
{
	PD0_DATA_B = ~PD0_DATA_B; //bitwise not
  CNT++;
}

int main(void)
{
	
	SysTickInit();

	PD0Init();
	
  while(1);
}
