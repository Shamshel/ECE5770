// main.c
// Runs on LM3S1968

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to the Arm Cortex M3",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2011
   Example 2.2, Program 2.8, Figure 2.27

 Copyright 2011 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

// UART TX: 9600 baud w/8 MHz clock 

// system control base addr
unsigned char *SYSCTL = (unsigned char *) 0x400FE000;
//UART0 shares pins with Port A (RX: PA0, TX: PA1)
unsigned char *PA = (unsigned char *) 0x40004000;
// UART0 base
unsigned char *UART0 = (unsigned char *) 0x4000C000;
unsigned char UART0_D __attribute__((at(0x4000C000)));
volatile unsigned int UART0_STAT __attribute__((at(0x4000C018)));

void UART0Init()
{
	// 0. set sysclk to main osc (8MHz crystal)
	// final value should be 0x078E3B82 (remember little endian)
  SYSCTL[0x60] = 0x82;
  SYSCTL[0x61] = 0x3B;
  SYSCTL[0x62] = 0x8E;
  SYSCTL[0x63] = 0x07;

  // 1. enable clock: uart then port
  SYSCTL[0x104] = 0x1; //uart0
  SYSCTL[0x108] = 0x1; //portA

  // 2. PA1: enable alt. func. and pin
  PA[0x420] = 0x2; //AFSEL
  PA[0x51C] = 0x2; //DEN
  
  // 3. disable uart0
  UART0[0x30] = 0x0;
  
  // 4. set baudrate divisor
  // BRD = 8e6/(16*9600)= 52.083
  // integer portion: int(52.083)=52
  UART0[0x24] = 0x34;
  // fractional portion: int(0.083*2^6+0.5)=6
  UART0[0x28] = 0x6;
  
  // 5. set serial parameters: 8-bit word, start/stop/parity bits
  UART0[0x2C] = 0x62;
  
  // 6. enable tx and uart
  UART0[0x30] = 0x01;
	UART0[0x31] = 0x1;
}
int main(void)
{
	unsigned char d;
	
	UART0Init();
	
	for(d=0;d<=255;d++)
	{
		UART0_D = d;
		while(UART0_STAT == 0x30);
	}
}
