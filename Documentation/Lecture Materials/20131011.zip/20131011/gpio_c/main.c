// main.c
// Runs on LM3S1968

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to the Arm Cortex M3",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2011
   Example 2.2, Program 2.8, Figure 2.27

 Copyright 2011 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */
// most of these could probably be char
volatile int PD_DATA_R __attribute__((at(0x400073FC)));       
volatile int PD_DIR_R __attribute__((at(0x40007400)));
volatile int PD_AF_R __attribute__((at(0x40007420)));      
volatile int PD_DEN_R __attribute__((at(0x4000751C)));
volatile int RCGC2_R __attribute__((at(0x400FE108)));
#define RCGC2_PD      0x00000008  //value for RCGC2 to enable clock for port D

int main(void)
{
	unsigned char z;
	
	// initialise port: RMW-cycle so much better in C...
	RCGC2_R |= RCGC2_PD; //activate port D: RCGC2 = RCGC2 | RCGC2_PD
  PD_DIR_R |= 0x0F;    //make PD3-0 output
  PD_AF_R &= 0x00;    //disable alt. func. 
  PD_DEN_R |= 0x0F; //enable digital I/O on PD3-0
	
	while(1)
	{
		for(z=0;z<16;z++)
			PD_DATA_R = z;
	}
	
	return 1;
}
