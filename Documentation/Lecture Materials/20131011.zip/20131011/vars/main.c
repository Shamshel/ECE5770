// main.c
// Runs on LM3S1968

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to the Arm Cortex M3",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2011
   Example 2.2, Program 2.8, Figure 2.27

 Copyright 2011 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */
 
unsigned char a __attribute__((at(0x20000040))); //put 'a' at given addr
#define b (*((unsigned char *) 0x20000041)) //setting b is like dereferncing a pointer that points to addr

int main(void)
{
	unsigned char c; //will be allocated to a register
  unsigned char *d = (unsigned char *) 0x20000043; //cast number as pointer to a byte, d is then assigned that number to point to
	
	a = 0xA;
	b = 0xB;
	c = 0xC;
	*d = 0xD;
	
	return 1;
}
