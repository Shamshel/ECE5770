// main.c
// Runs on LM3S1968

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to the Arm Cortex M3",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2011
   Example 2.2, Program 2.8, Figure 2.27

 Copyright 2011 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

// RCGC2 (for enabling clock to gpio port a/b)
unsigned int RCGC2 __attribute__((at(0x400FE108)));
// base addr for port a
unsigned char *PA = (unsigned char *) 0x40004000;
// base addr for port b
unsigned char *PB = (unsigned char *) 0x40005000;
// base (bitband) addr for port a pins
unsigned int *PA_B = (unsigned int *) 0x42087F80;
// base (bitband) addr for port b pins
unsigned int *PB_B = (unsigned int *) 0x420A7F80;
// port a pins
unsigned char KEYPAD __attribute__((at(0x400043FC)));
// port b pins
volatile unsigned char SSD __attribute__((at(0x400053FC)));

//what port looks like when each key is pressed (assume MSB is always one)
unsigned char KEYS[12] = {0xEE,0xDE,0xBE,0xED,0xDD,0xBD,0xEB,0xDB,0xBB,0xE7,0xD7,0xB7};
//what does port look like when key's row is grounded: needed to scan keypad
unsigned char RKEYS[12] = {0xFE,0xFE,0xFE,0xFD,0xFD,0xFD,0xFB,0xFB,0xFB,0xF7,0xF7,0xF7};
//bit combinations to display key on seven segment display: A,0,b,9,8,7,6,5,4,3,2,1
unsigned char SSDCH[12] = {0x88,0xC0,0x83,0x98,0x80,0xF8,0x82,0x92,0x99,0xB0,0xA4,0xF9};

void PABInit()
{
	// 1. activate clock for port a/b
  RCGC2 =  0x3;
	
  // 2. disable alt. function: disabled by default

  // 3a. set PA[3:0] as output, PA[7:4] as input
	PA[0x400] = 0xF;
	// 3b. set PB as output
	PB[0x400] = 0xFF;

  // 4. additional settings: PA[3:0]=1; PB=1
  PA[0x3FC] |= 0xF;
	PB[0x3FC] = 0xFF;
	
  // 5. enable pins 0--6 PA, 0--7 PB
	PA[0x51C] = 0xFF;
	PB[0x51C] = 0xFF;
}

void keyScan()
{
	unsigned char i;
	
	for(i=0;i<12;i++)
	{
		KEYPAD = RKEYS[i]; //ground row
		
		if(KEYPAD == KEYS[i]) //see if we've found the key
		{
			SSD = SSDCH[i]; //output char to SSD
			KEYPAD = 0xFF; //done scanning, return
			break;
		}
	}
}
	
int main(void)
{
	PABInit();
	
  while(1)
		keyScan();
}
