// io configuration registers
unsigned char *IOCON_P0_21 = (unsigned char *) 0x4002C054; //CAN_RD1
unsigned char *IOCON_P0_22 = (unsigned char *) 0x4002C058; //CAN_TD1
// power enable register
unsigned char *PCONP = (unsigned char *) 0x400FC0C4;
// ISER0 register (NVIC interrupt enable for IDs 0--31)
unsigned char *ISER0 = (unsigned char *) 0xE000E100;
// CAN1 base address
unsigned char *CAN1 = (unsigned char *) 0x40044000;
// acceptance filter config base address
unsigned char *AFC = (unsigned char *) 0x4003C000;
// acceptance filter base address
unsigned int *AF = (unsigned int *) 0x40038000;

// id of most recently received message
unsigned short ID;
// (up to) first four bytes of CAN messages
unsigned int MSG1;

void CANInit()
{
  // 1. power-on CAN1
	PCONP[0x1] = PCONP[0x1] | 0x20;

  // 4. pin config: CAN functionality, otherwise defaults
  IOCON_P0_21[0x0] = 0x4; //0x4=0b100
	IOCON_P0_22[0x0] = 0x4; //0x4=0b100
	
	// 5. enable interrupt for RX
	CAN1[0x10] = 0x1; //CAN1 interrupt enable
	ISER0[0x3] = ISER0[0x3] | 0x2; //NVIC interrupt enable for CAN
	
	// 6. setup acceptance filters
	// 6a. set bypass mode so we can setup filters
	AFC[0x0] = 0x3;
	// 6a. table start and stop addresses (one message ID accepted)
	AFC[0x4] = 0x0; //enable standard, individual
	AFC[0x14] = 0x4; //end of filter addr: bug in simulator, should be left shifted by two
	AFC[0x8] = AFC[0x14]; //disable standard,group
	AFC[0xC] = AFC[0x14]; //disable extended,individual
	AFC[0x10] = AFC[0x14]; //disable extended,group
	
	// 6b. define filters
	AF[0x0] = 0xAD;
	// 6c. enable filters and rx
	AFC[0x0] = 0x0;
	
	// 7. enable CAN1
	CAN1[0x0] = 0x0;
}

void CAN_IRQHandler()
{
	// ack IRQ (by releasing receiver buffer)
  CAN1[0x4] = CAN1[0x4] | 0x4;

  // get message bytes and id
	ID = CAN1[0x24];
	MSG1 = CAN1[0x28];
	
	// based on ID, send response
	if(ID==0xAD)
	{
		CAN1[0x32] = 0x1; //want to tx one byte (set DLC)
		CAN1[0x34] = 0xAD; //ID
		CAN1[0x38] = MSG1+1; //message
		CAN1[0x4] = CAN1[0x4] | 0x21; //transmit buffer one
	}
}

int main(void)
{
	CANInit();

  while(1);
}
