#include <stdio.h>
#include <stdlib.h>

int main(void)
{
  char cKey[12]; /* key is 10 digits + check */

  while(1)
    {
      printf("Please enter your activation key to continue: ");
      
      fgets(cKey,12,stdin);
      
      if(checkKey(cKey)==1)
	break;
    }

  keyVerified();

  return 1;
}

int checkKey(char* key)
{
  int ikey[12];
  int i,lastDigit;
  int sum=0; 

  /* convert string to int for easy key verification. */
  for(i=0;i<11;i++)
    ikey[i]=key[i]-'0';
    
  /* verify key according to secret algorithm */
  /* RGERDES: actually it's easier to calculate the check bit than it is to do the verification. so we'll do that */
  for(i=0;i<10;i++)
    sum = sum + ikey[i];

  lastDigit = (sum*9) % 10;

  if(lastDigit == ikey[10])
    return 1;
  else
    return 0;
}

int keyVerified()
{
  printf("Think you're pretty tough, eh?\n");

  return 1;
}
